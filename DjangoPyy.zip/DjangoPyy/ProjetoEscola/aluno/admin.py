from django.contrib import admin

# Register your models here.
from .models import aluno 

admin.site.register(aluno)