from django.contrib import admin

# Register your models here.
from .models import Turma

admin.site.register(Turma)